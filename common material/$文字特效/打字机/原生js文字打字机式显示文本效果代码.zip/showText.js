﻿/*******************************
 函数：打字机式显示文本
 函数原型：showText(text,element,property,time);
 参数说明：
 text 要显示的文本
 element 用于显示的元素
 property 将要改变的属性
	其数值可以为以下四种中的一种：
		0."innerHTML"
		1."innerText"
		2."title"
		3."value"
		注：数值或者字符串均可，区分大小写。
	分别对应节点的四个属性
 time 连续出现的两个字符的间隔时间
	单位毫秒
	可选
	默认值100
/*******************************/
function showText(text,element,property,time)
{
	var i=0;
	var loop;
	if(property==0||property=="innerHTML") loop=setInterval(function(){if(i>=text.length||!element||element.innerHTML==undefined)clearInterval(loop);element.innerHTML+=text.charAt(i++);},time?time:100);
	else if(property==1||property=="innerText") loop=setInterval(function(){if(i>=text.length||!element||element.innerText==undefined)clearInterval(loop);element.innerText+=text.charAt(i++);},time?time:100);
	else if(property==2||property=="title") loop=setInterval(function(){if(i>=text.length||!element||element.title==undefined)clearInterval(loop);element.title+=text.charAt(i++);},time?time:100);
	else if(property==3||property=="value") loop=setInterval(function(){if(i>=text.length||!element||element.value==undefined)clearInterval(loop);element.value+=text.charAt(i++);},time?time:100);
}