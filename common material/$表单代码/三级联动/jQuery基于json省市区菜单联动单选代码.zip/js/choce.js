/**
 * Created by Administrator on 2018/5/8.
 */
$(function () {
    //遍历省市区
    $.each(citys,function(item,content){
        var shenName=content.name;
        //遍历省
        var shenHtml=
            "<li class='shen-list all-list-style clearfloat s"+item+item+"'>"+
            "<div class='lf ts-checked center checked-icon-all'>"+
            "<i class='box-icon-style'></i>"+
            "</div>"+
            "<div class='lf province-name over-text'>"+shenName+"</div>"+
            "</li>";
        $("#provinceAll").append(shenHtml);
        $.each(content.city,function(indexs,contentCity){
            //遍历市
            var cityName=contentCity.name;

            var cityHtml=
                "<li class='city-list all-list-style clearfloat s"+item+item+" s"+item+item+indexs+" s"+item+item+item+indexs+"'>"+
                "<div class='lf ts-checked center checked-icon-all'>"+
                "<i class='box-icon-style'></i>"+
                "</div>"+
                "<div class='lf province-name  over-text'>"+cityName+"</div>"+
                "</li>";


            $("#cityAll").append(cityHtml);
            //点击出现省对应城市
            $("#provinceAll .s"+item+item).click(function(){
                $(".city-list").hide();
                $("#cityAll .s"+item+item).show();
                $("#areaAlls").hide();

            });
            //遍历区
            var result = [];
            result.push(contentCity.area);

            $.each(result,function(areaitem,contentArea){
                var areaName=contentArea;

                $.each(areaName,function(newItem,newContent){
                    var newareaName=newContent;
                    var areaHtml=
                        "<div class='every-area all-list-style s"+item+item+item+indexs+"'>"+
                        "<div class='lf ts-checked center checked-icon-all'>"+
                        "<i class='box-icon-style'></i>"+
                        "</div>"+
                        "<div class='lf province-name over-text'>"+newareaName+"</div>"+
                        "</div>";
                    $("#areaAlls").append(areaHtml);


                    //点击出现对应的区域

                    $("#cityAll .s"+item+item+item+indexs).click(function(){
                        $("#areaAlls").show();
                        $(".every-area").hide();
                        $("#areaAlls .s"+item+item+item+indexs).show();

                    });
                });
            });
        });
    });
    $(".all-list-style").click(function(){
        if( $(this).find(".box-icon-style").hasClass("opacity1")){
//                $(this).find(".box-icon-style").removeClass("opacity1");
        }else{
            $(this).find(".box-icon-style").addClass("opacity1");
            $(this).siblings(".all-list-style").find(".box-icon-style").removeClass("opacity1");
        }
    });
});