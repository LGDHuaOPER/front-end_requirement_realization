<?php 
	$servername = "localhost";
	$username = "root";
	$userpwd = "casey";
	$mydb = "myweibo";

	$conn = new mysqli($servername,$username,$userpwd,$mydb);

	if($conn->connect_error){
		die("链接失败:". $conn->connect_error);
	}

	// 创建数据库
	// $sql = "CREATE TABLE weibocon (
	// 'id' INT(6) NOT NULL AUTO_INCREMENT PRIMARY KEY, 
	// 'content' TEXT NOT NULL,
	// 'time' INT NOT NULL,
	// 'acc' INT NOT NULL,
	// 'ref' INT NOT NULL
	// )";
	$sql = "CREATE TABLE MyGuests (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	content TEXT NOT NULL,
	acc INT NOT NULL,
	ref INT NOT NULL,
	reg_date INT NOT NULL
	)";
	$conn->query("set name 'utf8'");
	if($conn->query($sql) === TRUE){
		echo "数据表创建成功";
	}else{
		echo "创建数据表失败：".$conn->error;
	}

	



 ?>