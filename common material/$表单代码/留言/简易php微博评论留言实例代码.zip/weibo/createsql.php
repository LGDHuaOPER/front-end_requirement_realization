<?php 
	$servername = "localhost";
	$username = "root";
	$userpwd = "casey";

	$conn = new mysqli($servername,$username,$userpwd);

	if($conn->connect_error){
		die("链接失败:". $conn->connect_error);
	}

	// 创建数据库
	$sql = "CREATE DATABASE myweibo";
	if($conn->query($sql) === TRUE){
		echo "数据库创建成功";
	}else{
		echo "创建数据库失败：".$conn->error;
	}



 ?>