$(document).ready(function() {


});

var type_nums = 0;	//记录选择了几道题
var timer = [];	//计时器
var tag = 0;
/**随机选取试题 - 开始选择**/
function sjxzst() {
	$("input:checkbox[name='type']:checked").each(function() {
		var type = $(this).val();
		$(".sjxzst_content ."+type).show();
		type_nums++;
	});
	if(type_nums == 0){
		alert("最少选择一种考试类型");
	}else{
		//改变随机div的宽，并居中
		$(".sjxzst").width(200*type_nums +"px").css("margin-left",(200*type_nums)/2*(-1) + "px");
		$(".sjxzst").show();
		$("input:checkbox[name='type']:checked").each(function() {
			var type = $(this).val();
			if(type == "qy"){
				tag = 0;
				choose_music(type);
			}
			if(type == "sy"){
				tag = 1;
				choose_music(type);
			}
			if(type == "sc"){
				tag = 2;
				choose_music(type);
			}
		});
	}
	
}

/**随机选取试题 - 通过随机数选择**/
function stop_music(){
	clearInterval(timer[0]);
	clearInterval(timer[1]);
	clearInterval(timer[2]);
}

/**随机选取试题 - 通过随机数选择**/
function choose_music(type){
	var startTime = new Date().getTime();
	var nums = $(".sjxzst_list ."+type+" p").length;
	timer[tag] = setInterval(function(){
		$(".sjxzst_content ."+type+" input").val($(".sjxzst_list ."+type).children().eq(parseInt(Math.random()*nums)).find("input").val());
		$(".sjxzst_content ."+type+" p").html($(".sjxzst_list ."+type).children().eq(parseInt(Math.random()*nums)).html());
		
//		if(new Date().getTime() - startTime > 5000){
//			clearInterval(timer);
//			return;
//		}
	},100);
	
}

/**随机选取试题 - 关闭**/
function sjxzst_close() {
	$("input:checkbox[name='type']").each(function() {
		var type = $(this).val();
		$(".sjxzst_content ."+type).hide();
	});
	type_nums = 0;
	$(".sjxzst").hide();
}
