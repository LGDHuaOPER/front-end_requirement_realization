$(function(){
    // =================================loading控制
    $(window).on("load",function(){
        $("#loading").delay(50).fadeOut()
    });
})