
var E = function () {
        function a(f, d) {
            try {
                return f.contains ? f != d && f.contains(d) : !! (f.compareDocumentPosition(d) & 16)
            } catch (g) {}
        }
        function b(g, f, e) {
            function d(j) {
                var i = j.currentTarget,
                    h = j.relatedTarget;
                if (!a(i, h) && i != h) {
                    e.call(j.currentTarget, j)
                }
            }
            if (g.addEventListener) {
                if (f == "mouseenter") {
                    g.addEventListener("mouseover", d, false)
                } else {
                    if (f == "mouseleave") {
                        g.addEventListener("mouseout", d, false)
                    } else {
                        g.addEventListener(f, e, false)
                    }
                }
            } else {
                g.attachEvent("on" + f, e)
            }
        }
        function c(d) {
            if (typeof d == "undefined") {
                d = window.event
            }
            if (typeof d.layerX == "undefined") {
                d.layerX = d.offsetX
            }
            if (typeof d.layerY == "undefined") {
                d.layerY = d.offsetY
            }
            if (typeof d.pageX == "undefined") {
                d.pageX = d.clientX + document.body.scrollLeft - document.body.clientLeft
            }
            if (typeof d.pageY == "undefined") {
                d.pageY = d.clientY + document.body.scrollTop - document.body.clientTop
            }
            return d
        }
        return {
            fixEvent: c,
            addEvent: b
        }
    }();
var T = function () {
        function a(k, m) {
            var j = document.createElement("script");
            j.onload = j.onreadystatechange = function () {
                if (!j.readyState || "loaded" === j.readyState || "complete" === j.readyState) {
                    m && m();
                    j.onload = j.onreadystatechange = null;
                    j.parentNode.removeChild(j)
                }
            };
            j.src = k;
            var l = document.getElementsByTagName("head")[0];
            l.insertBefore(j, l.firstChild)
        }
        function i(j, l, n, k, m) {
            document.cookie = j + "=" + encodeURIComponent(l) + ("; expires=" + new Date(new Date().getTime() + (( !! n) ? n * 1 : 1) * 24 * 60 * 60 * 1000).toGMTString()) + (( !! m) ? "; path=" + m : "/") + (( !! k) ? "; domain=" + k : "domain=" + window.location.host)
        }
        function g(j) {
            return decodeURIComponent(document.cookie.replace(new RegExp(".*(?:^|; )" + j + "=([^;]*).*|.*"), "$1"))
        }
        function d(q, o, k) {
            var n = new Array();
            if (o == null) {
                o = document
            }
            if (k == null) {
                k = "*"
            }
            var m = o.getElementsByTagName(k);
            var p = new RegExp("(^|\\s)" + q + "(\\s|$)");
            for (var l = 0, j = m.length; l < j; l++) {
                if (p.test(m[l].className)) {
                    n.push(m[l])
                }
            }
            return n
        }
        function b(j) {
            return {
                left: j.getBoundingClientRect().left + document.documentElement.scrollLeft - document.documentElement.clientLeft,
                top: j.getBoundingClientRect().top + document.documentElement.scrollTop - document.documentElement.clientTop
            }
        }
        function e(l, j) {
            var k = " ",
                m = k + l.className + k;
            return m.indexOf(k + j + k) != -1 ? true : false
        }
        function f(k, j) {
            if (!e(k, j)) {
                k.className += " " + j
            }
        }
        function h(m, j) {
            var l = new RegExp(j, "gi"),
                k = m.className.replace(l, "");
            m.className = k
        }
        function c() {
            var j = {};
            if ( !! document.cookie.match(/(^|; )common_session_id=[^;]+/) && !! document.cookie.match(/(^|; )cmu=([^;]+)/)) {
                j.hasLogined = true
            } else {
                j.hasLogined = false
            }
            if (T.getCookie("babyBirthday") != "") {
                j.hasSetDate = true;
                j.babyBirthday = T.getCookie("babyBirthday")
            } else {
                j.hasSetDate = false;
                j.babyBirthday = null
            }
            return j
        }
        return {
            loadScript: a,
            getUserState: c,
            getElementsByClass: d,
            addClass: f,
            removeClass: h,
            setCookie: i,
            getCookie: g,
            getPageXY: b
        }
    }();

function slide(a) {
    this.handle = a.handle;
    this.slider = a.slider;
    this.needMove = typeof a.needMove == "undefined" ? true : a.needMove;
    this.hoverClass = a.hoverClass;
    this.boxCount = this.handle.getElementsByTagName(a.boxTag || "li").length;
    this.showLeftX = 0;
    this.showRightX = this.handle.offsetWidth;
    this.config = a;
    this.init()
}
slide.prototype = {
    _curChoose: "",
    init: function () {
        var a = this,
            e = a.handle,
            d = a.slider;
        if (a.needMove) {
            a.smallSliderWidth = d.clientWidth;
            E.addEvent(e, "mouseenter", function () {
                T.addClass(e, a.hoverClass);
                a.bigSliderWidth = d.clientWidth
            });
            E.addEvent(e, "mouseleave", function (k) {
                k = E.fixEvent(k);
                var j = -parseInt(d.style.marginLeft);
                var i = a.smallSliderWidth,
                    f = parseInt(k.pageX - e.getBoundingClientRect().left),
                    l = e.clientWidth,
                    g = a.bigSliderWidth,
                    m = j + f;
                var n = (m * i) / g,
                    h = n - f;
                if (h < 0) {
                    h = i - l
                } else {
                    if (h > i - l) {
                        h = i - l
                    }
                }
                d.style.marginLeft = -h + "px";
                T.removeClass(e, a.hoverClass)
            });
            E.addEvent(e, "mousemove", function (h) {
                h = E.fixEvent(h);
                var g = d.clientWidth,
                    f = e.clientWidth,
                    j = h.pageX - e.getBoundingClientRect().left;
                var k = (j * g) / f,
                    i = k - j;
                d.style.marginLeft = -i + "px"
            })
        }
        var c = e.getElementsByTagName("a");
        for (var b = 0; b < c.length; b++) {
            (function (f) {
                var g = c[f];
                E.addEvent(g, "mouseover", function () {
                    a.showTitle(g, g.getAttribute("title"))
                })
            })(b)
        }
    },
    hideTitle: function () {
        document.getElementById("axis-title").style.display = "none"
    },
    showTitle: function (d, c) {
        var b = document.getElementById("axis-title");
        var a = T.getPageXY(d);
        if (!b) {
            var e = document.createElement("div");
            e.id = "axis-title";
            e.style.position = "absolute";
            document.body.appendChild(e);
            b = e
        }
        b.innerHTML = c;
        b.style.display = "block";
        b.style.left = (a.left + d.offsetWidth / 2 - b.offsetWidth / 2) + "px"
	b.style.top = (a.top - b.offsetHeight+3) + "px";
    },
    showIndex: function (h) {
        var k = this,
            d = k.config,
            b = k.slider,
            c = k.handle.getElementsByTagName(d.boxTag || "li");
        if (h > k.boxCount || h <= 0) {
            return
        }
        if ( !! slide._curChoose && slide._curChoose != "") {
            T.removeClass(slide._curChoose, "choose")
        }
        T.addClass(c[h - 1], "choose");
        slide._curChoose = c[h - 1];
        if (k.needMove) {
            T.addClass(k.handle, k.hoverClass);
            var f = k.slider.clientWidth,
                i = k.handle.clientWidth,
                g = c[0].offsetWidth + 1;
            var j = (h * g - g / 2),
                a = i / f * j,
                e = j - a;
            b.style.marginLeft = -e + "px"
        }
    }
};
if (typeof (HTMLElement) != "undefined") {
    HTMLElement.prototype.contains = function (obj) {
        while (obj != null && typeof (obj.tagName) != "undefined") {
            if (obj == this) return true;
            obj = obj.parentNode
        }
        return false
    }
}
function _initSlide(id,className,firsstNeedMove){
var eleShows = T.getElementsByClass(className, document.getElementById(id));
var eleReals = document.getElementById(id).getElementsByTagName("ul");
for (var i = 0; i < eleShows.length; i++) {
    new slide({
        hoverClass: "hover",
        needMove:i>0?1: firsstNeedMove,
        handle: eleShows[i],
        slider: eleReals[i],
        boxTag: "li"
    });
    eleShows[i].onmouseout = function (e) {
        e = e || event;
        e = e.toElement || e.relatedTarget;
        if (typeof (e) != "undefined" && !this.contains(e)) {
            document.getElementById("axis-title").style.display = "none"
        }
    }
}
}
function _initSlides(id,className,firsstNeedMove){
var eleShows = T.getElementsByClass(className, document.getElementById(id));
var eleReals = document.getElementById(id).getElementsByTagName("ul");
for (var i = 0; i < eleShows.length; i++) {
    new slide({
        hoverClass: "hover",
        needMove:i>7?1: firsstNeedMove,
        handle: eleShows[i],
        slider: eleReals[i],
        boxTag: "li"
    });
    eleShows[i].onmouseout = function (e) {
        e = e || event;
        e = e.toElement || e.relatedTarget;
        if (typeof (e) != "undefined" && !this.contains(e)) {
            document.getElementById("axis-title").style.display = "none"
        }
    }
}
}
_initSlide("J_tb","chke_jia",0);
_initSlides("J_tb1","tb-show",0);