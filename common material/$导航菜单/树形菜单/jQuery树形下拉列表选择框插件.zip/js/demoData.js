var treeData = [
	{
		name: "一级导航",
		open:true,
		'state' : {  
           'opened' : true,  
           'selected' : true  
         }, 
		children: [
			{
				name: "1栋",
				open:true,
				'state' : {
                    'opened' : true,  
                    'selected' : true  
                },
                children:[
	                {name: "1单元"},
					{name: "2单元"},
					{name: "3单元"},
                ]
            }
		]
	}
];