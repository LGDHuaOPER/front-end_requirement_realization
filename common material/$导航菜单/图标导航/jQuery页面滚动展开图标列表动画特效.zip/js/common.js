var loadAnimate = function () {
    var getDom = [];
    $(".load-animate[data-animate-name][data-animate-delay][data-animate-duration]").each(function (i, dom) {
        dom = $(dom);
        dom.is(':visible') && getDom.push({
            'dom': dom,
            'st': dom.attr('style') || '',
            'oTop': dom.offset().top,
            'loaded': false,
            'aName': dom.data('animate-name'),
            'aDelay': dom.data('animate-delay'),
            'aDuration': dom.data('animate-duration')
        });
    });
    var addAnimate = function (s, h) {
        if (getDom.length > 0) {
            $.map(getDom, function (v, i) {
                if (!v.loaded && ((v.oTop > s && v.oTop < s + h) || (v.oTop < s && v.oTop + v.dom.height() > s))) {
                    if ($.browser && $.browser.msie && $.browser.msie < 9) {
                        v.dom.removeClass('load-animate');
                        v.loaded = true;
                    } else {
                        v.dom.addClass('animated ' + v.aName).css({
                            'animation-delay': v.aDelay,
                            'animation-duration': v.aDuration
                        });
                        setTimeout(function () {
                            v.dom.removeClass('load-animate');
                        }, v.aDelay.slice(0, v.aDelay.length - 1) * 1000);
                        setTimeout(function () {
                            v.dom.attr('style', v.st).removeClass('animated ' + v.aName);
                        }, v.aDelay.slice(0, v.aDelay.length - 1) * 1000 + v.aDuration.slice(0, v.aDuration.length - 1) * 1000 + 10);
                        v.loaded = true;
                        if (v.evContainer) {
                            v.dom.attr('data-loadAnimate', 1).data('loadAnimate', 1);
                        }
                    }
                }
            });
        }
    };
    var window_ = window.top;
    $(window_).on({
        'scroll.loadAnimate': function () {
            addAnimate($(this).scrollTop(), $(this).height());
        }
    });
    addAnimate($(window_).scrollTop(), $(window_).height());
};
$(function(){

    loadAnimate();
});