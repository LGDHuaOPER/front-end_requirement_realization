$(document).ready(function(){
	$(".page1 .page1_list li").click(function(){
		$(this).children('div')	.slideToggle().show();					  
								  })				   
})