/**
 * Created by Administrator on 2017/8/1 0001.
 */
$(document).ready(function() {

    $(".layout-title li").click(function() {
        $(this).addClass('current').siblings().removeClass('current');
        var index = $(this).index();
        $(".layout-intro").hide();
        $(".layout-intro").eq(index).show();
        if (index == 0) {
            $(".chinamap").show();
            $(".worldmap").hide();
        } else {
            $(".chinamap").hide();
            $(".worldmap").show();
        }
    });
    $(".chinamap .point").hover(function() {
        $(this).addClass('hovers').siblings().removeClass('hovers');
        var cityStr = $(this).data("id");
        $(".layout-desc").hide();
        $(".layout-desc").each(function() {
            if ($(this).data("content") == cityStr) $(this).show();
        });
    });
    $(".worldmap .point").hover(function() {
        $(this).addClass('hovers').siblings().removeClass('hovers');
        var cityStr = $(this).data("id");
        $(".layout-desc").hide();
        $(".layout-desc").each(function() {
            if ($(this).data("content") == cityStr) $(this).show();
        });
    });
    $(".layout-tab-title li").click(function(event) {
        $(this).addClass('current').siblings().removeClass('current');
        var index = $(this).index();
        $(this).parent().next().next().find("p").hide();
        $(this).parent().next().next().find("p").eq(index).show();
        $(this).parents(".layout-tab").prev().find("a").hide();
        $(this).parents(".layout-tab").prev().find("a").eq(index).show();
    });



});
