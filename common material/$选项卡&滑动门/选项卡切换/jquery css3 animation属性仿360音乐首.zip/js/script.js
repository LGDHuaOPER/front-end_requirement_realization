$(function(){
		   
	(function() {
		function a(e) {
			if (e == u) return;
			var r = t.eq(u),
			s = t.eq(e);
			r.css("z-index", 1).fadeOut(500),
			s.css("z-index", 0).fadeIn(500),
			n.eq(u).removeClass(i),
			n.eq(e).addClass(i),
			u = e
		}
	})(),

	function() {
		function e(e, t) {
			t = t || {};
			var n = $(this),
			r = t.tabSelecter || ".tabs li",
			i = t.viewSelector || ".views .view-item",
			s = $(e),
			o = s.find(r),
			u = s.find(i),
			a = [1],
			f = "active",
			l = 0;
			return n.host = s,
			s.delegate(r, "click",
			function(e) {
				e.preventDefault();
				var t = o.index(this),
				r = o.eq(t),
				i = u.eq(t);
				o.eq(l).removeClass(f),
				u.eq(l).removeClass(f),
				r.addClass(f),
				i.addClass(f),
				l = t,
				n.trigger("switch", {
					tab: r,
					view: i
				})
			}),
			n
		}
		$.TabView = e
	} (),
	function() {
		var e = new $.TabView(".top-vrank");
		e.on("switch",
		function(t, n) {
			e.host.find(".more a").attr("href", "http://" + n.tab.attr("data-type"))
		}),
		$(".top-vrank .tabs li").click(function() {
			$(".top-vrank .view-item").removeClass("first")
		})
	} ()
	
});
