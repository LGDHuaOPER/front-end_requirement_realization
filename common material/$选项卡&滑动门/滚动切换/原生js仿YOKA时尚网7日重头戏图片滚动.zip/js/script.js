//ѡ����
function $a(id,tag){var re=(id&&typeof id!="string")?id:document.getElementById(id);if(!tag){return re;}else{return re.getElementsByTagName(tag);}}

function movec()//����ƶ�
{
	var o=$a("bd1lfimg");
	var oli=$a("bd1lfimg","dl");//����LI�б�
    var oliw=oli[0].offsetWidth;//ÿ���ƶ��Ŀ���
	var ow=o.offsetWidth-2;
	var dnow;//=oli.length-3;//��ǰλ��
	var day=(new Date()).getDay();
	switch(day)
	{
		case 1:dnow=0;break;
		case 2:dnow=1;break;
		case 3:dnow=2;break;
		case 4:dnow=3;break;
		case 5:dnow=4;break;
		case 6:dnow=5;break;
		case 0:dnow=6;break;
	}
	var olf=oliw-(ow-oliw+10)/2;
		o["scrollLeft"]=olf+(dnow*oliw);
	var rqbd=$a("bd1lfsj","ul")[0];
	var extime;
	var rqnr=["","MON","TUE","WED","THU","FRI","SAT","SUN",""];

	for(var i=1;i<oli.length-1;i++){rqbd.innerHTML+="<li>"+rqnr[i]+"</li>";}

	var rq=$a("bd1lfsj","li");
	for(var i=0;i<rq.length;i++){reg(i);};
	oli[dnow+1].className=rq[dnow].className="show";
	var wwww=setInterval(uu,3000);

	function reg(i){rq[i].onclick=function(){oli[dnow+1].className=rq[dnow].className="";dnow=i;oli[dnow+1].className=rq[dnow].className="show";mv();}}
	function mv(){clearInterval(extime);clearInterval(wwww);extime=setInterval(bc,15);wwww=setInterval(uu,3000);}
	function bc()
	{
		var ns=((dnow*oliw+olf)-o["scrollLeft"]);
		var v=ns>0?Math.ceil(ns/10):Math.floor(ns/10);
		o["scrollLeft"]+=v;if(v==0){clearInterval(extime);oli[dnow+1].className=rq[dnow].className="show";v=null;}
	}
	function uu()
	{
		if(dnow<oli.length-3)
		{
			oli[dnow+1].className=rq[dnow].className="";
			dnow++;
			oli[dnow+1].className=rq[dnow].className="show";
		}
		else{oli[dnow+1].className=rq[dnow].className="";dnow=0;oli[dnow+1].className=rq[dnow].className="show";}
		mv();
	}
}

